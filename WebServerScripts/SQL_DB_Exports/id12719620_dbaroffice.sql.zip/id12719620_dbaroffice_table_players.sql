
-- --------------------------------------------------------

--
-- Table structure for table `players`
--

DROP TABLE IF EXISTS `players`;
CREATE TABLE IF NOT EXISTS `players` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL,
  `hash` varchar(100) NOT NULL,
  `salt` varchar(50) NOT NULL,
  `score` int(10) NOT NULL DEFAULT 5,
  `FullName` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `players`
--

INSERT INTO `players` (`id`, `username`, `hash`, `salt`, `score`, `FullName`) VALUES
(21, 'shivamhcu', '$5$rounds=5000$SteamedHamsshiva$kp4KndS7TxWnlxfTXsD8ktrBjE/CsJsRe./HKT2/jM0', '$5$rounds=5000$SteamedHamsshivamhcu$', 5, 'shivam gangwar'),
(22, 'AkshaymIT', '$5$rounds=5000$SteamedHamsAksha$/JfEoe133qPS.8gGzPHdG2qBQkRO3R1s2q2v.rCMyT0', '$5$rounds=5000$SteamedHamsAkshaymIT$', 5, 'akshay kumar prasad'),
(23, '', '$5$rounds=5000$SteamedHams$qgdwuKpBsLb1Iqa2y/OxJ1xNaTLpPNA3nqGzIKd03PB', '$5$rounds=5000$SteamedHams$', 5, '');
