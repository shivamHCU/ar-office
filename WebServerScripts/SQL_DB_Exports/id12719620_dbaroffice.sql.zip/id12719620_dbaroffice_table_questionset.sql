
-- --------------------------------------------------------

--
-- Table structure for table `questionset`
--

DROP TABLE IF EXISTS `questionset`;
CREATE TABLE IF NOT EXISTS `questionset` (
  `quesid` int(11) NOT NULL AUTO_INCREMENT,
  `questext` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `noOfOpt` int(11) NOT NULL,
  `option1` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `option2` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `option3` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `option4` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `correctOptionNo` int(11) NOT NULL,
  `domain` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`quesid`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `questionset`
--

INSERT INTO `questionset` (`quesid`, `questext`, `noOfOpt`, `option1`, `option2`, `option3`, `option4`, `correctOptionNo`, `domain`) VALUES
(1, 'When does the ArrayIndexOutOfBoundsException occur?', 4, 'Compiletime', 'Runtime', 'Not an exception', 'Not an error', 2, 'shivamhcu-TNQT19'),
(6, 'Which of the following concepts make extensive use of arrays?', 4, 'Spatial locality', 'Caching', 'Process Scheduling', 'Binary trees', 1, 'shivamhcu-TNQT19'),
(7, 'The process of accessing data stored in a serial access memory is similar to manipulating data on a __?', 4, 'Array', 'Heap', 'Tree', 'Stack', 4, 'shivamhcu-TNQT19'),
(8, 'Efficiency of finding the next record in B+ tree is __?', 4, 'O(log n)', 'O(n log n)', 'O(1)', 'O(n)', 3, 'shivamhcu-TNQT19'),
(9, 'A single channel is shared by multiple signals by __?', 4, 'digital modulation', 'modulation', 'analog modulation', 'multiplexing', 4, 'shivamhcu-TNQT19'),
(20, 'jhsgfidskgfiudsikadgadfh?', 4, 'jdsbfkbk', 'mdsbgkjdsbkjv', 'lkdfnlkdfngkld', 'jdgbskjvkdsj', 3, 'shivamhcu-Delhi'),
(21, 'Which of the following correctly declares an array?', 4, 'int geeks[20]', 'int geeks;', 'geeks{20};', 'array geeks[20];', 1, 'shivamhcu-TNQT19'),
(22, 'Which of  the following correctly declares an array?', 4, 'int geeks[20]', 'int geeks;', 'array geeks[20]', 'int[20] geeks;', 1, 'shivamhcu-TNQT19'),
(23, 'Which of the following correctly declares an array?\r\n', 4, 'int geeks[20]\r', 'int geeks;\r', 'geeks{20};', 'array geeks[20];', 1, 'shivamhcu-TNQT19');
